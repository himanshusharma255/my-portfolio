// Paste into Extensions > Apps Script of your Google Sheet.
// Sheet tab must be named Sheet1.
const RECIPIENT_EMAIL = "him1972000@gmail.com";

function doPost(e) {
  try {
    const data = e.parameter;
    const name = (data.Name || "").trim();
    const email = (data.Email || "").trim();
    const message = (data.Message || "").trim();
    if (!name || !email || !message) throw new Error("Missing required fields");

    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Sheet1");
    if (!sheet) throw new Error("Sheet1 tab not found");
    // Prefix user text to prevent spreadsheet formula injection.
    const safe = (v) => /^[=+@\-]/.test(v) ? "'" + v : v;
    sheet.appendRow([new Date(), safe(name), safe(email), safe(message)]);

    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: "Portfolio contact: " + name.replace(/[\r\n]/g, " "),
      body: "Name: " + name + "\nEmail: " + email + "\n\nMessage:\n" + message,
      replyTo: email
    });
    return ContentService.createTextOutput("OK");
  } catch (err) {
    console.error(err);
    return ContentService.createTextOutput("ERROR: " + err.message);
  }
}
